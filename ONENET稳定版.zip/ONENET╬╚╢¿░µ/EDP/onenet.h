#ifndef _ONENET_H_
#define _ONENET_H_
#include "sys.h"




_Bool OneNet_DevLink(void);

void OneNet_SendData(int data);
void OneNet_SendData_humi(int data);
void OneNet_SendData_light(int data);
void OneNet_SendData_Air(int data);
void OneNet_SendData_S1(int data);
void OneNet_SendData_S2(int data);
void OneNet_RevPro(unsigned char *cmd);

_Bool OneNet_PushData(const char* dst_devid, const char* data, unsigned int data_len);
	
#endif
