/**
	************************************************************
	************************************************************
	************************************************************
	*	???: 	EdpKit.c
	*
	*	??: 		???
	*
	*	??: 		2017-09-13
	*
	*	??: 		V1.1
	*
	*	??: 		EDP??
	*
	*	????:	V1.1:?strncpy???memcpy,????bug
	************************************************************
	************************************************************
	************************************************************
**/

//?????
#include "EdpKit.h"


//C?
#include <string.h>


//==========================================================
//	????:	EDP_NewBuffer
//
//	????:	????
//
//	????:	edpPacket:????
//				size:??
//
//	????:	?
//
//	??:		1.????????????
//				2.???????????????
//==========================================================
void EDP_NewBuffer(EDP_PACKET_STRUCTURE *edpPacket, uint32 size)
{
	
	uint32 i = 0;

	if(edpPacket->_data == NULL)
	{
		edpPacket->_memFlag = MEM_FLAG_ALLOC;
		
		edpPacket->_data = (uint8 *)EDP_MallocBuffer(size);
		if(edpPacket->_data != NULL)
		{
			edpPacket->_len = 0;
			
			edpPacket->_size = size;

			for(; i < edpPacket->_size; i++)
				edpPacket->_data[i] = 0;
		}
	}
	else
	{
		edpPacket->_memFlag = MEM_FLAG_STATIC;
		
		for(; i < edpPacket->_size; i++)
			edpPacket->_data[i] = 0;
		
		edpPacket->_len = 0;
		
		if(edpPacket->_size < size)
			edpPacket->_data = NULL;
	}

}

//==========================================================
//	????:	EDP_DeleteBuffer
//
//	????:	??????
//
//	????:	edpPacket:????
//
//	????:	?
//
//	??:		?????????????????
//==========================================================
void EDP_DeleteBuffer(EDP_PACKET_STRUCTURE *edpPacket)
{

	if(edpPacket->_memFlag == MEM_FLAG_ALLOC)
		EDP_FreeBuffer(edpPacket->_data);
	
	edpPacket->_data = NULL;
	edpPacket->_len = 0;
	edpPacket->_size = 0;
	edpPacket->_memFlag = MEM_FLAG_NULL;

}

//==========================================================
//	????:	EDP_UnPacketRecv
//
//	????:	EDP????????
//
//	????:	dataPtr:???????
//
//	????:	0-??		??-????
//
//	??:		
//==========================================================
uint8 EDP_UnPacketRecv(uint8 *dataPtr)
{
	
	return dataPtr[0];

}

//==========================================================
//	????:	EDP_PacketConnect1
//
//	????:	????1??
//
//	????:	devid:??ID
//				apikey:APIKEY
//				cTime:??????
//				edpPacket:???
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint1 EDP_PacketConnect1(const int8 *devid, const int8 *apikey, uint16 cTime, EDP_PACKET_STRUCTURE *edpPacket)
{
	
	uint8 devid_len = strlen(devid);
	uint8 apikey_len = strlen(apikey);

	//????---------------------------------------------------------------------
	EDP_NewBuffer(edpPacket, 56);
	if(edpPacket->_data == NULL)
		return 1;
	
	//Byte0:????--------------------------------------------------------------
	edpPacket->_data[0] = CONNREQ;
	edpPacket->_len++;
	
	//Byte1:??????----------------------------------------------------------
	edpPacket->_data[1] = 13 + devid_len + apikey_len;
	edpPacket->_len++;
	
	//Byte2~3:?????----------------------------------------------------------
	edpPacket->_data[2] = 0;
	edpPacket->_data[3] = 3;
	edpPacket->_len += 2;
	
	//Byte4~6:???--------------------------------------------------------------
	strncat((int8 *)edpPacket->_data + 4, "EDP", 3);
	edpPacket->_len += 3;
	
	//Byte7:????--------------------------------------------------------------
	edpPacket->_data[7] = 1;
	edpPacket->_len++;
	
	//Byte8:????--------------------------------------------------------------
	edpPacket->_data[8] = 0x40;
	edpPacket->_len++;
	
	//Byte9~10:??????-------------------------------------------------------
	edpPacket->_data[9] = MOSQ_MSB(cTime);
	edpPacket->_data[10] = MOSQ_LSB(cTime);
	edpPacket->_len += 2;
	
	//Byte11~12:DEVID??---------------------------------------------------------
	edpPacket->_data[11] = MOSQ_MSB(devid_len);
	edpPacket->_data[12] = MOSQ_LSB(devid_len);
	edpPacket->_len += 2;
	
	//Byte13~13+devid_len:DEVID---------------------------------------------------
	strncat((int8 *)edpPacket->_data + 13, devid, devid_len);
	edpPacket->_len += devid_len;
	
	//Byte13+devid_len~13+devid_len+2:APIKEY??----------------------------------
	edpPacket->_data[13 + devid_len] = MOSQ_MSB(apikey_len);
	edpPacket->_data[14 + devid_len] = MOSQ_LSB(apikey_len);
	edpPacket->_len += 2;
	
	//Byte15+devid_len~15+devid_len+apikey_len:APIKEY-----------------------------
	strncat((int8 *)edpPacket->_data + 15 + devid_len, apikey, apikey_len);
	edpPacket->_len += apikey_len;
	
	return 0;

}

//==========================================================
//	????:	EDP_PacketConnect2
//
//	????:	????2??
//
//	????:	devid:??ID
//				auth_key:????
//				cTime:??????
//				edpPacket:???
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint1 EDP_PacketConnect2(const int8 *proid, const int8 *auth_key, uint16 cTime, EDP_PACKET_STRUCTURE *edpPacket)
{
	
	uint8 proid_len = strlen(proid);
	uint8 authkey_len = strlen(auth_key);

	//????---------------------------------------------------------------------
	EDP_NewBuffer(edpPacket, 56);
	if(edpPacket->_data == NULL)
		return 1;
	
	//Byte0:????--------------------------------------------------------------
	edpPacket->_data[0] = CONNREQ;
	edpPacket->_len++;
	
	//Byte1:??????----------------------------------------------------------
	edpPacket->_data[1] = 15 + proid_len + authkey_len;
	edpPacket->_len++;
	
	//Byte2~3:?????----------------------------------------------------------
	edpPacket->_data[2] = 0;
	edpPacket->_data[3] = 3;
	edpPacket->_len += 2;
	
	//Byte4~6:???--------------------------------------------------------------
	strncat((int8 *)edpPacket->_data + 4, "EDP", 3);
	edpPacket->_len += 3;
	
	//Byte7:????--------------------------------------------------------------
	edpPacket->_data[7] = 1;
	edpPacket->_len++;
	
	//Byte8:????--------------------------------------------------------------
	edpPacket->_data[8] = 0xC0;
	edpPacket->_len++;
	
	//Byte9~10:??????-------------------------------------------------------
	edpPacket->_data[9] = MOSQ_MSB(cTime);
	edpPacket->_data[10] = MOSQ_LSB(cTime);
	edpPacket->_len += 2;
	
	//Byte11~12:DEVID??---------------------------------------------------------
	edpPacket->_data[11] = 0;
	edpPacket->_data[12] = 0;
	edpPacket->_len += 2;
	
	//Byte13~14:PROID??---------------------------------------------------------
	edpPacket->_data[13] = MOSQ_MSB(proid_len);
	edpPacket->_data[14] = MOSQ_LSB(proid_len);
	edpPacket->_len += 2;
	
	//Byte15~15+proid_len:RPOID---------------------------------------------------
	strncat((int8 *)edpPacket->_data + 15, proid, proid_len);
	edpPacket->_len += proid_len;
	
	//Byte15+devid_len~15+proid_len+1:APIKEY??----------------------------------
	edpPacket->_data[15 + proid_len] = MOSQ_MSB(authkey_len);
	edpPacket->_data[16 + proid_len] = MOSQ_LSB(authkey_len);
	edpPacket->_len += 2;
	
	//Byte17+proid_len~17+proid_len+apikey_len:APIKEY-----------------------------
	strncat((int8 *)edpPacket->_data + 17 + proid_len, auth_key, authkey_len);
	edpPacket->_len += authkey_len;
	
	return 0;

}

//==========================================================
//	????:	EDP_UnPacketConnectRsp
//
//	????:	??????
//
//	????:	rev_data:??????
//
//	????:	????
//
//	??:		
//==========================================================
uint8 EDP_UnPacketConnectRsp(uint8 *rev_data)
{

	//0		????
	//1		????:????
	//2		????:??ID????
	//3		????:?????
	//4		????:??ID????
	//5		????:???
	//6		????:?????
	//7		????:??????
	//8		????:???????
	//9		????:?????????
	return rev_data[3];

}

int32 WriteRemainlen(uint8 *buf, uint32 len_val, uint16 write_pos)
{
	
	int32 remaining_count = 0;
	uint8 byte = 0;

	do
	{
		byte = len_val % 128;
		len_val = len_val >> 7;
		/* If there are more digits to encode, set the top bit of this digit */
		if (len_val > 0)
		{
			byte = byte | 0x80;
		}
		buf[write_pos++] = byte;
		remaining_count++;
	} while(len_val > 0 && remaining_count < 5);

	return --write_pos;
}

int32 ReadRemainlen(int8 *buf, uint32 *len_val, uint16 read_pos)
{
	
    uint32 multiplier = 1;
    uint32 len_len = 0;
    uint8 onebyte = 0;
	
    *len_val = 0;
	
    do
	{
        onebyte = buf[read_pos++];

        *len_val += (onebyte & 0x7f) * multiplier;
        multiplier <<= 7;

        len_len++;
        if (len_len > 4)
		{
            return -1;/*len of len more than 4;*/
        }
    } while((onebyte & 0x80) != 0);
	
    return read_pos;
}

//==========================================================
//	????:	EDP_PacketSaveJson
//
//	????:	?????
//
//	????:	devid:??ID(???)
//				send_buf:json??buf
//				send_len:json??
//				type_bin_head:bin??????
//				type:??
//				edpPacket:???
//
//	????:	0-??		1-??
//
//	??:		???Type2???,type_bin_head??NULL
//==========================================================
uint8 EDP_PacketSaveData(const int8 *devid, int16 send_len, int8 *type_bin_head, SaveDataType type, EDP_PACKET_STRUCTURE *edpPacket)
{

	int16 remain_len = 0;
	uint8 devid_len = strlen(devid);
	
	if(type == 2 && type_bin_head == NULL)
		return 1;
	
	if(type == 2)
		EDP_NewBuffer(edpPacket, strlen(type_bin_head));
	else
		EDP_NewBuffer(edpPacket, send_len + 24);
	if(edpPacket->_data == NULL)
		return 2;

	//Byte0:????--------------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = SAVEDATA;
	
	if(devid)
	{
		if(type == 2)
			remain_len = 12 + strlen(type_bin_head) + send_len;
		else
			remain_len = 8 + send_len + devid_len;
		
		//??????-------------------------------------------------------------
		edpPacket->_len += WriteRemainlen(edpPacket->_data, remain_len, edpPacket->_len);
		
		//??--bit7:1-?devid,0-?devid		bit6:1-?????,0-?????----
		edpPacket->_data[edpPacket->_len++] = 0xC0;
		
		//DEVID??---------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = 0;
		edpPacket->_data[edpPacket->_len++] = devid_len;
		
		//DEVID------------------------------------------------------------------
		strncat((int8 *)edpPacket->_data + edpPacket->_len, devid, devid_len);
		edpPacket->_len += devid_len;
		
		//????----------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = MSG_ID_HIGH;
		edpPacket->_data[edpPacket->_len++] = MSG_ID_LOW;
	}
	else
	{
		if(type == 2)
			remain_len = 10 + strlen(type_bin_head) + send_len;
		else
			remain_len = 6 + send_len;
		 
		//??????------------------------------------------------------------
		edpPacket->_len += WriteRemainlen(edpPacket->_data, remain_len, edpPacket->_len);
		
		//??--bit7:1-?devid,0-?devid		bit6:1-?????,0-?????----
		edpPacket->_data[edpPacket->_len++] = 0x40;
		
		//????----------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = MSG_ID_HIGH;
		edpPacket->_data[edpPacket->_len++] = MSG_ID_LOW;
	}
	
	edpPacket->_data[edpPacket->_len++] = type;
	
	if(type == 2)
	{
		uint8 type_bin_head_len = strlen(type_bin_head);
		uint8 i = 0;
		
		//?????---------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = MOSQ_MSB(type_bin_head_len);
		edpPacket->_data[edpPacket->_len++] = MOSQ_LSB(type_bin_head_len);
		
		//???-------------------------------------------------------------------
		for(; i < type_bin_head_len; i++)
			edpPacket->_data[edpPacket->_len++] = type_bin_head[i];
		
		//????-----------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = (uint8)(send_len >> 24);
		edpPacket->_data[edpPacket->_len++] = (uint8)(send_len >> 16);
		edpPacket->_data[edpPacket->_len++] = (uint8)(send_len >> 8);
		edpPacket->_data[edpPacket->_len++] = (uint8)send_len;
	}
	else
	{
		//json??-----------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = MOSQ_MSB(send_len);
		edpPacket->_data[edpPacket->_len++] = MOSQ_LSB(send_len);
	}
	
	return 0;

}

//==========================================================
//	????:	EDP_PacketPushData
//
//	????:	PushData????
//
//	????:	devid:??ID
//				msg:????
//				msg_len:???????
//				edpPacket:???
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint8 EDP_PacketPushData(const int8 *devid, const int8 *msg, uint32 msg_len, EDP_PACKET_STRUCTURE *edpPacket)
{
	
	uint32 remain_len = 2 + strlen(devid) + msg_len;
	uint8 devid_len = strlen(devid);
	uint16 i = 0;
	uint16 size = 5 + strlen(devid) + msg_len;
	
	if(devid == NULL || msg == NULL || msg_len == 0)
		return 1;

	EDP_NewBuffer(edpPacket, size);
	if(edpPacket->_data == NULL)
		return 2;
	
	//Byte0:pushdata??-----------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = PUSHDATA;
	
	//????----------------------------------------------------------------------
	edpPacket->_len += WriteRemainlen(edpPacket->_data, remain_len, edpPacket->_len);
	
	//DEVID??---------------------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = MOSQ_MSB(devid_len);
	edpPacket->_data[edpPacket->_len++] = MOSQ_LSB(devid_len);
	
	//??DEVID---------------------------------------------------------------------
	for(; i < devid_len; i++)
		edpPacket->_data[edpPacket->_len++] = devid[i];
	
	//????----------------------------------------------------------------------
	for(i = 0; i < msg_len; i++)
		edpPacket->_data[edpPacket->_len++] = msg[i];
	
	return 0;

}

//==========================================================
//	????:	EDP_UnPacketPushData
//
//	????:	PushData????
//
//	????:	rev_data:?????
//				src_devid:?devid??
//				req:????
//				req_len:????
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint8 EDP_UnPacketPushData(uint8 *rev_data, int8 **src_devid, int8 **req, uint32 *req_len)
{

	int32 read_pos = 0;
	uint32 remain_len = 0;
	uint16 devid_len = 0;
	
	//Byte0:PushData??------------------------------------------------------------
	if(rev_data[read_pos++] != PUSHDATA)
		return 1;

	//??????--------------------------------------------------------------------
	read_pos = ReadRemainlen((int8 *)rev_data, &remain_len, read_pos);
	if(read_pos == -1)
		return 2;
	
	//???devid??-----------------------------------------------------------------
	devid_len = (uint16)rev_data[read_pos] << 8 | rev_data[read_pos + 1];
	read_pos += 2;

	//????------------------------------------------------------------------------
	*src_devid = (int8 *)EDP_MallocBuffer(devid_len + 1);
	if(*src_devid == NULL)
		return 3;

	//???devid---------------------------------------------------------------------
	memset(*src_devid, 0, devid_len + 1);
	memcpy(*src_devid, (const int8 *)rev_data + read_pos, devid_len);
	read_pos += devid_len;

	remain_len -= 2 + devid_len;

	//????------------------------------------------------------------------------
	*req = (int8 *)EDP_MallocBuffer(remain_len + 1);
	if(*req == NULL)
	{
		EDP_FreeBuffer(*src_devid);
		return 4;
	}

	//????------------------------------------------------------------------------
	memset(*req, 0, remain_len + 1);
	memcpy(*req, (const int8 *)rev_data + read_pos, remain_len);
	read_pos += remain_len;

	*req_len = remain_len;
	
	return 0;

}

//==========================================================
//	????:	EDP_UnPacketCmd
//
//	????:	??????
//
//	????:	rev_data:?????
//				cmdid:cmdid
//				cmdid_len:cmdid??
//				req:??
//				req_len:????
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint8 EDP_UnPacketCmd(uint8 *rev_data, int8 **cmdid, uint16 *cmdid_len, int8 **req, uint32 *req_len)
{

	uint32 remain_len = 0;
	int32 read_pos = 0;
	
	//Byte0:PushData??------------------------------------------------------------
	if(rev_data[read_pos++] != CMDREQ)
		return 1;
	
	//??????--------------------------------------------------------------------
	read_pos = ReadRemainlen((int8 *)rev_data, &remain_len, read_pos);
	if(read_pos == -1)
		return 2;
	
	//??cmdid??-------------------------------------------------------------------
	*cmdid_len = (uint16)rev_data[read_pos] << 8 | rev_data[read_pos + 1];
	read_pos += 2;
	
	//????------------------------------------------------------------------------
	*cmdid = (int8 *)EDP_MallocBuffer(*cmdid_len + 1);
	if(*cmdid == NULL)
		return 3;
	
	//??cmdid-----------------------------------------------------------------------
	memset(*cmdid, 0, *cmdid_len + 1);
	memcpy(*cmdid, (const int8 *)rev_data + read_pos, *cmdid_len);
	read_pos += *cmdid_len;
	
	//??req??---------------------------------------------------------------------
	*req_len = (uint32)rev_data[read_pos] << 24 | (uint32)rev_data[read_pos + 1] << 16
					 | (uint32)rev_data[read_pos + 2] << 8 | (uint32)rev_data[read_pos + 3];
	read_pos += 4;
	
	//????------------------------------------------------------------------------
	*req = (int8 *)EDP_MallocBuffer(*req_len + 1);
	if(*req == NULL)
	{
		EDP_FreeBuffer(*cmdid);
		return 4;
	}
	
	//??req-------------------------------------------------------------------------
	memset(*req, 0, *req_len + 1);
	memcpy(*req, (const int8 *)rev_data + read_pos, *req_len);
	read_pos += *req_len;
	
	return 0;

}

//==========================================================
//	????:	EDP_PacketCmdResp
//
//	????:	??????
//
//	????:	cmdid:???cmdid(?????)
//				cmdid_len:cmdid??
//				req:??
//				req_len:????
//				edpPacket:???
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint1 EDP_PacketCmdResp(const int8 *cmdid, uint16 cmdid_len, const int8 *resp, uint32 resp_len, EDP_PACKET_STRUCTURE *edpPacket)
{
	
	uint32 remain_len = cmdid_len + resp_len + (resp_len ? 6 : 2);
	
	EDP_NewBuffer(edpPacket, remain_len + 5);
	if(edpPacket->_data == NULL)
		return 1;
	
	//Byte0:CMDRESP??------------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = CMDRESP;
	
	//??????------------------------------------------------------------------
	edpPacket->_len += WriteRemainlen(edpPacket->_data, remain_len, edpPacket->_len);
	
	//??cmdid??------------------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = cmdid_len >> 8;
	edpPacket->_data[edpPacket->_len++] = cmdid_len & 0x00FF;
	
	//??cmdid----------------------------------------------------------------------
	memcpy((int8 *)edpPacket->_data + edpPacket->_len, cmdid, cmdid_len);
	edpPacket->_len += cmdid_len;
	
	if(resp_len)
	{
		//??req??-----------------------------------------------------------------
		edpPacket->_data[edpPacket->_len++] = (uint8)(resp_len >> 24);
		edpPacket->_data[edpPacket->_len++] = (uint8)(resp_len >> 16);
		edpPacket->_data[edpPacket->_len++] = (uint8)(resp_len >> 8);
		edpPacket->_data[edpPacket->_len++] = (uint8)(resp_len & 0x00FF);
		
		//??req---------------------------------------------------------------------
		memcpy((int8 *)edpPacket->_data + edpPacket->_len, resp, resp_len);
		
		edpPacket->_len += resp_len;
	}

	return 0;

}

//==========================================================
//	????:	EDP_PacketPing
//
//	????:	??????
//
//	????:	edpPacket:???
//
//	????:	0-??		1-??
//
//	??:		
//==========================================================
uint1 EDP_PacketPing(EDP_PACKET_STRUCTURE *edpPacket)
{


	EDP_NewBuffer(edpPacket, 2);
	if(edpPacket->_data == NULL)
		return 1;
	
	//Byte0:PINGREQ??------------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = PINGREQ;    //??C0
	
	//Byte1:0----------------------------------------------------------------------
	edpPacket->_data[edpPacket->_len++] = 0;          //??00
	
  ESP8266_SendData(edpPacket->_data, edpPacket->_len);	  //????? 
	return 0;

}


